transform cinematic_zoom:
    xalign 0.5
    yalign 0.5
    zoom 1.0
    linear 8.0 zoom 1.15

transform run:
    xoffset 0
    yoffset 0

    parallel:
        linear 0.10 yoffset -15
        linear 0.10 yoffset 0
        repeat

    parallel:
        linear 0.05 xoffset 8
        linear 0.05 xoffset -8
        repeat

transform unstable_breathing:
    zoom 1.0
    xoffset 0

    parallel:
        linear 0.12 zoom 1.05
        linear 0.12 zoom 1.0
        repeat

    parallel:
        linear 0.08 xoffset 2
        linear 0.08 xoffset -2
        repeat

transform slow_twist:
    rotate 0
    linear 2.0 rotate 2
    linear 2.0 rotate -2
    repeat

transform heartbeat:
    zoom 1.0
    ease 0.25 zoom 1.08
    ease 0.25 zoom 1.0
    pause 0.6
    repeat
    
transform left_edge:
    xalign 0.0
    xoffset -120

transform right_edge:
    anchor (1.0, 1.0)
    align (1.0, 1.0)
    xoffset 150
    
transform sprite_default:
    zoom 0.45
    yalign 1.0
    yoffset 120
    
transform shake:
    xoffset 0
    yoffset 0
    linear 0.05 xoffset 10
    linear 0.05 xoffset -10
    repeat

transform fast_zoom:
    zoom 1.0
    linear 0.6 zoom 2

transform zoom:
    zoom 1.0
    linear 5.0 zoom 1.15

transform slow_zoom:
    zoom 1.0
    linear 4.0 zoom 1.5

transform shake_zoom:
    zoom 1.0
    
    parallel:
        easeout 0.7 zoom 1.25   # the zoom
    
    parallel:
        linear 0.05 xoffset 10  # the shake
        linear 0.05 xoffset -10
        repeat

# images
image bg bathroom = im.Scale("images/backgrounds/bathroom.jpg", 1920, 1080)
image bg bathtub = im.Scale("images/backgrounds/bathtub.jpg", 1920, 1080)
image You_ghost = "images/characters/You_ghost.png"
image You_underworld = "images/characters/You_underworld.jpg"
image bg daniel_bathtub = "images/backgrounds/daniel_bathtub.jpg" 
image bg gloves = "images/backgrounds/gloves.jpg" 
image Lilian_murder = "images/characters/lilian_murder.jpg"
image Daniel_murder = "images/characters/daniel_murder.jpg"
image bg bathroomdoor = "images/backgrounds/bathroomdoor.jpg"
image bg bathroomdooropen = "images/backgrounds/bathroomdooropen.jpg"
image bg city = "images/backgrounds/city.jpg"
image bg streets = "images/backgrounds/streets.jpg"
image bg figures = "images/backgrounds/figures.jpg"
image bg ghost = "images/backgrounds/ghost.jpg"
image bg oldwoman = "images/backgrounds/oldwoman.jpg"
image bg triangle = "images/backgrounds/triangle.jpg"
image rock_rock = "images/characters/rock.jpg"
image bg womanface= "images/backgrounds/womanface.jpg"
image bg womanleave= "images/backgrounds/womanleave.jpg"
image bg endless_stairs= "images/backgrounds/endless_stairs.jpg"
image bg endless_streets= "images/backgrounds/endless_streets.jpg"
image bg endingcity= "images/backgrounds/endingcity.jpg"
image bg gameover= "images/backgrounds/gameover.jpg"
image bg vision= "images/backgrounds/vision.jpg"
image bg bedroom= "images/backgrounds/bedroom.jpg"
image Lilian_happy= "images/characters/lilian_happy.png"
image Lilian_good= "images/characters/lilian_good.png"
image Daniel_good= "images/characters/daniel_good.png"
image bg couple= "images/backgrounds/couple.jpg"
image bg runstreet= "images/backgrounds/runstreet.jpg"
image bg basement= "images/backgrounds/basement.jpg"
image bg waterdoor= "images/backgrounds/waterdoor.jpg"
image bg zoomdoor= "images/backgrounds/zoomdoor.jpg"
image bg lake= "images/backgrounds/lake.jpg"
image bg dive= "images/backgrounds/dive.jpg"
image bg route= "images/backgrounds/route.jpg"
image bg lake= "images/backgrounds/lake.jpg"
image bg cello= "images/backgrounds/cello.jpg"
image bg black= "images/backgrounds/cello.jpg"
image bg trees= "images/backgrounds/trees.jpg"


############################################
# CHARACTERS
############################################

define s = Character("You")
define d = Character("Daniel")
define l = Character("Lilian")
define ghost = Character("Ghost Voice")
define old_woman = Character("Old Woman")
define rock_c = Character("Rock")
define you = Character("You", who_color="#aaaaaa")
define you_v = Character("You")


############################################
# START
############################################

label start:

    jump scene_0_bathroom_awakening


############################################
# SCENE 0 — THE BATHROOM AWAKENING
############################################

label scene_0_bathroom_awakening:

    scene bg bathroom at shake

    "Cold bathroom. Fluorescent light hum. Mirror fogged. Sink dripping."
    "You try to inhale."
    "Nothing happens."

    scene bg bathtub at slow_zoom

    "You lift your head and see the bathtub."
    "And inside it—"
    "Your body."

    show You_ghost at left_edge, sprite_default
    s "…Oh."
    hide You_ghost
    
    "A long pause."

    show You_ghost at left_edge, sprite_default
    s "I’m dead."
    hide You_ghost

    scene bg daniel_bathtub at slow_zoom
    "You look down. Your husband is kneeling beside your body, calm and methodical."
    
    scene bg gloves at cinematic_zoom
    "He already has gloves in his pocket."

    scene bg bathroom
    
    show Lilian_murder at right_edge
    l "No way we really did it…"
    hide Lilian_murder

    show Daniel_murder at right_edge
    d "It’ll be okay. She has outgrown us a long time ago."
    hide Daniel_murder

    show Lilian_murder at right_edge
    l "She trusted us so much, I was her best friend.."
    hide Lilian_murder

    show Daniel_murder at right_edge
    d "Hey listen. I'll take care of this, no one is gonna know. I have access to all her bank acounts and dont forget the insurance money. The future is bright for us."
    hide Daniel_murder

    show You_ghost at left_edge, sprite_default
    s "..."
    hide You_ghost

    scene bg bathroomdoor
    "The bathroom door creaks open by itself."

    scene bg bathroomdooropen
    with dissolve
    "A dark hallway stretches beyond it."
    "Something is calling you."
    "Not a voice. Not a sound."
    "A direction."

    scene bg bathroomdooropen at zoom
    "You step into the hallway."

    jump scene_2_in_between_city


############################################
# SCENE 2 — IN-BETWEEN CITY
############################################

label scene_2_in_between_city:

    scene bg city at cinematic_zoom
    "On the other side of the door you see a city at twilight. No sun. No moon. No stars."

    scene bg streets
    with dissolve

    "Buildings look unfinished."
    "Streets stretch endlessly."

    scene bg figures at cinematic_zoom
    with dissolve
    "Figures move like prey."

    scene bg ghost at shake_zoom
    with dissolve
    "You bump into a ghost"

    scene bg ghost 
    ghost "Hmmm. New arrival."


    show You_underworld at right_edge
    you "I don't belong here. I need to go back."
    hide You_underworld

    ghost "They all say that. Only the ones with unanswered questions get stuck here."

    show You_underworld at right_edge
    you "I won’t stay here."
    hide You_underworld

    ghost "They all say that too."

    menu:

        "What drives you?"

        "I need revenge.":
            scene bg triangle at cinematic_zoom
            "Sadness came first, then anger. They planned it. They had prepared. You had been living inside a performance without being the director."
            "Daniel was your only family, you were the only one left. And now, you are the only one left who knows the ending is wrong."

        "I need answers.":
            scene bg triangle at cinematic_zoom
            "Something doesn’t add up."
            "Their voices didn’t sound panicked. No shaking hands. No confusion. No fear."
            "Like they had rehearsed this conversation before you ever stopped breathing."
            "If this place is built from unfinished things…"
            "Then the truth must still be somewhere inside it."


    scene bg ghost 
    with dissolve
    "The ghost fades into the fog and Irish goodbyed."
    scene bg figures at cinematic_zoom
    "You keep walk down the endless street. The street of murdered, betrayed, wronged."
    "The city loops without warning. Turn left, then right, then back again—and you are exactly where you started."

    jump scene_3_old_woman


############################################
# SCENE 3 — OLD WOMAN
############################################

label scene_3_old_woman:

    scene bg oldwoman at shake_zoom
    "Then you collide with her."

    scene bg oldwoman at cinematic_zoom
    "An old woman. Small, bent, almost folded into herself."
    "One eye is missing entirely."
    
    old_woman "I was almost there."
    show You_underworld at right_edge
    you "Where?"
    hide You_underworld

    old_woman "My son’s apartment. I promised I’d visit him and his girlfriend."
    old_woman "The light was green. The driver didn’t stop. My lingering soul saw he hit and ran."

    scene bg womanface at cinematic_zoom
    "She reaches for you."

    old_woman "Will you walk with me? I’m scared of the cars on the street."

    menu:

        "Take her hand and help her cross":
            scene bg oldwoman
            "You walked her acrosse the street. Her hand is lighter than paper."
            old_woman "Thank you. I didn’t want to be alone."
            old_woman "I think this rock will help you find your answers."
            show rock_rock
            "She presses a rock into your palm."
            hide rock_rock
            scene bg womanleave at cinematic_zoom
            "Before you have time to react, the old woman fades into the fog."

        "Ask her questions about this world":
            scene bg oldwoman
            old_woman "Everyone here was on their way somewhere."
            old_woman "Unfinished journeys don’t end."
            old_woman "I think this rock will help you find your answers."
            show rock_rock
            "The old woman presses the rock into your palm."
            hide rock_rock
            scene bg womanleave at cinematic_zoom
            "Before you have time to react, the old woman fades into the fog."
    

        "Pull away and leave her behind":
            scene bg oldwoman
            old_woman "…Oh."
            scene bg womanleave at cinematic_zoom

            "She walks toward the crossing."
            "Then turns around and does it again. And again."

            scene bg figures at cinematic_zoom
            "You shrug and keep walking. You're in overwelming misery. You don't have the mental capacity to help another person. "

            scene bg endless_streets at cinematic_zoom
            "The streets begin repeating."
            scene bg endless_stairs at cinematic_zoom
            "Corners lead to corners."
            "Stairs lead to more stairs."
            scene bg figures at cinematic_zoom
            "You are still here. Not moving forward. Not going back."
            scene bg oldwoman 
            with dissolve
            "Eventually, you see her again."
            "Standing at the curb."
            "Waiting."

            scene bg womanface at shake
            with dissolve
            old_woman "The light was green."
            scene bg womanface
            old_woman "Oh good. You’re still here."

            scene bg endingcity at cinematic_zoom
            "You are trapped in the In-Between forever."
            scene bg gameover at shake
            "Maybe kindness would have changed something."

            return

    jump scene_rock


############################################
# ROCK SCENE
############################################

label scene_rock:
    scene bg figures 
    show rock_rock 
    "Its surface is dark, like river-worn glass, but without reflection."
    show rock_rock at heartbeat
    "The stone pulses once. A slow heartbeat. Then again."
    rock_c "Before the lake darkens and the tree rises, you must remember who you were."
    show rock_rock at heartbeat
    rock_c "When you loved him, was it love… or the fear of being alone? Both of your parents died when you were a kid. I met them before."
    hide rock_rock

menu:
    "It was love, even if it hurt you.":
        pass
    "You didn’t know the difference.":
        pass
    "You were afraid of being alone.":
        pass

show rock_rock at heartbeat
rock_c "If you return to life by taking another’s place, will you call it survival… or theft?"
hide rock_rock

menu:
    "Survival. You deserve to live.":
        pass
    "Both. Survival built on theft.":
        pass
    "Theft. But you might do it anyway.":
        pass

show rock_rock at heartbeat
rock_c "If the person who hurt you begged for forgiveness, would you choose justice… or mercy?"
hide rock_rock

menu:
    "Justice. Some things cannot be forgiven.":
        pass
    "Mercy. Carrying hate is another prison.":
        pass
    "You don’t know what you would choose.":
        pass

show rock_rock at heartbeat
rock_c "You remember enough."
rock_c "This city repeats because you are afraid to leave it. Run. Do not stop. Do not look back. If you keep running, the streets will end. You will find trees."
rock_c "A dark lake waits beyond. In the center stand two trees. Between them is a doorway back to the living."
rock_c "A way for a wandering soul… to take the place of someone still alive."
hide rock_rock

menu:

    "Start running":
        "You run without thinking."
        scene bg endless_streets at run
        "Hours pass. No trees. No lake. No end."
        "Doubt begins to whisper."
        scene bg vision at cinematic_zoom
        "Then the world splits open."
        "A vision crashes into you like cold water."
        
        jump vision

    "Hesitate":
        scene bg endless_streets at cinematic_zoom
        "You don’t run because thoughts are flowing your brain."
        "Lilian and Daniel sit in your mind like two versions of the same betrayal. One you called your best friend. One you called your home."
        "According to the rock, if you hijack any of of them, their soul diminishes forever"
        "You try to choose between them. But every time you reach for one, the other bleeds through."
        scene bg vision at cinematic_zoom
        "Sunddenly the world splits open and a vision fills your head."
        jump vision
        

############################################
# VISION + FINAL SEQUENCE
############################################

label vision:
    scene bg bedroom 
    "Your bedroom."
    show Lilian_happy
    "Lilian is studying herself in YOUR mirror, trying on YOUR dressees."
    hide Lilian_happy 
    
    show Daniel_good
    "Daniel sits comfortably on the edge of your bed."
    hide Daniel_good

    show Lilian_happy
    l "Do you think this one looks natural?"
    hide Lilian_happy

    show Daniel_good
    d "It suits you. You should wear those colors more often."
    hide Daniel_good

    scene bg couple at cinematic_zoom
    "They look perfect together. Like you were the misplaced piece."
    "The vision snaps."
    scene bg endless_streets at unstable_breathing
    with dissolve
    "Anger floods your chest."
    scene bg endless_streets at run
    "You run."

    scene bg runstreet at run
    "The streets glitch and crumble behind you."
    
    scene bg route at run
    "Buildings stretch and dissolve into fog."
    "You see the moon again and realized that you don't remember the last time you saw it."
    scene bg trees at run
    "Also ahead — trees."
    "The city is finally disappearing."

    scene bg lake at cinematic_zoom
    "You reach the lake and see the two trees."

    scene bg dive at cinematic_zoom
    with dissolve
    "You dive in."
    "Freezing water swallows you."
    "You sink until your feet hit solid ground."

    scene bg waterdoor at cinematic_zoom
    with dissolve
    "A door stands at the bottom of the lake."
    scene bg waterdoor at cinematic_zoom
    "Your bedroom door."
    scene bg zoomdoor at cinematic_zoom
    "Your hand reaches for the handle."
    "......A way for a wandering soul… to take the place of someone still alive."

    menu:
        "Open the door and hijack Daniel's body":
            jump ending_husband

        "Open the door and hijack Lilian's body":
            jump ending_lilian


############################################
# ENDING 2 — HUSBAND
############################################

label ending_husband:
    scene bg black 
    "You did not return as Shirley. Shirley is missing, frozen at the height of success."
    "You returned as Daniel."
    scene bedroom
    s "Living in this body is not really a punishment for me. I carry his history and mine layered together." 

    scene basement at cinematic_zoom
    "At night, when the house above is quiet and no one is around, you descend into the basement and play cello."
    "Your hands were larger now, heavier, the bow foreign in your grip."
    scene cello 
    "But when you play, You're Shirley again."  
    scene gameover
    "ENDING — LOVE AS POSSESSION"
    return


############################################
# ENDING 3 — LILIAN
############################################

label ending_lilian:
    scene bg black at cinematic_zoom
    "You step into Lilian’s body."

    scene bedroom 

    "Upstairs, your husband calls:"
    show Daniel_good
    "“Lilian?”"
    hide Daniel_good

    show Lilian_good
    s "“Yes.” You hear yourself answer."

    scene bg couple at cinematic_zoom
    "Your husband kisses your forehead."
    "You smile perfectly."
    scene bedroom
    show Lilian_good
    s "Some lives are better when someone else finishes them."
    scene gameover 
    "ENDING: IMMA GET THAT MAN."
    return